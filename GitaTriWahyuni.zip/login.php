<!doctype>
<html>
	<head>
		<title>Tentang Desa Kertayasa</title>
		<link rel='stylesheet' href='theme/css/style.css'/>
	</head>
	
	<body>
	<!-- Main Header -->
		<div class='main-header'>
			<h2>Tentang desa Kertayasa</h2>
		</div>
		<nav>
			<ul>
				<li><a href='index.php'>Home</a></li>
				<li><a href='artikel.php'>artikel</a></li>
				<li><a href='index.php'>login</a></li>

			</ul>
		</nav>
	<!--Container-->
			<div class='main-wrapper'><center>
					<h2>Selamat Datang di Desa Kertayasa</h2><br/><hr><br/>
					
					<div class='title'>
						<h3>Login Area</h3>
					</div>
					<form action="proses_login.php" method="POST">
					<div class='widget'>
						<form method='POST' action='#'>
							<input type='text' name='username' placeholder='Username...'/><br/><br/>
							<input type='password' name='password' placeholder='*******'/><br/><br/>
							<input type='submit' value='Login !' class='button'>
						</form>
					</div>
				</div>
				
			</div></center>
			<div class='footer'>
				<p>Copyright &copy; 2018 - Kertayasa Banjarnegara</p>
			</div>
		</div>
	
	</body>
</html>