<?php
	include 'connect.php';
	$noprofil = $_POST['noprofil'];
	$judulprofil = $_POST['judulprofil'];
	$isiprofil = $_POST['isiprofil'];
	$submit = $_POST ['submit'];

	if(isset($submit)){

		if(empty($judulprofil) or empty($isiprofil)){

		echo "<script>alert('Form tidak boleh kosong. Silahkan ulangi lagi'); window.location=('profilinput.php') </script>";
		}else{
			$input = mysqli_query($koneksi, "INSERT INTO profil (noprofil,judulprofil, isiprofil) values ('$noprofil','$judulprofil', '$isiprofil')");
			echo "<script>alert('Berhasil'); window.location=('profildata.php'); </script>";
		}
	}
?>