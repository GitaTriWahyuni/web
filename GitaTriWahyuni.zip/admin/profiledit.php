<!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' href='theme/css/style.css'/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
<!-- Main Header -->
        <div class='main-header'>
            <h2>Wonderful Banjarnegara</h2>
        </div>
        <nav>
            <ul>
                <li><a href='index.php'>Web</a></li>
                <li><a href='logout.php'>Logout</a></li>
            </ul>
        </nav>
    <!--Container-->

</head>
<body>
<br>
<br>
<?php
include 'connect.php';
$id= $_GET["id"];
$query=mysqli_query ($koneksi, "SELECT * FROM profil WHERE noprofil ='$id'");
$fec=mysqli_fetch_array($query);
?>
<center><h2>Tambah Profil</h2></center>

<div class="container">
  <form action="profilprosesedit.php" method="POST">
    <label for="fname">No Profil</label>
    <input type="text" id="fname" placeholder="Your name.." name="noprofil" value='<?php echo $fec["noprofil"];?>'>

    <label for="lname">judul profil</label>
    <input type="text" id="lname" placeholder="Your last name.." name="judulprofil" value='<?php echo $fec["judulprofil"];?>'>


    <label for="subject">isi profil</label>
    <br>
    <textarea id="subject" placeholder="Write something.." style="height:200px" name="isiprofil"> <?php echo $fec["isiprofil"];?></textarea>
    <br>
    <input type="submit" name="submit" value="submit">
  </form>
</div>

</body>
</html>
