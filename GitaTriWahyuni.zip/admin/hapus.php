<?php
include 'connect.php';
//menyimpan data ke dalam variabel
$id = $_GET["id"];
//query SQL untuk insert data
$query = "DELETE from profil WHERE noprofil='$id'";
mysqli_query($koneksi, $query);
//mengalikan ke dalam index.php
header("location:profildata.php");
?>