<!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' href='theme/css/style.css'/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
<!-- Main Header -->
        <div class='main-header'>
            <h2>Wonderful Banjarnegara</h2>
        </div>
        <nav>
            <ul>
                <li><a href='index.php'>Web</a></li>
                <li><a href='logout.php'>Logout</a></li>
            </ul>
        </nav>
    <!--Container-->

</head>
<body>
<br>
<br>
<center><h2>Tambah Profil</h2></center>

<div class="container">
  <form action="profil_proses.php" method="POST">
    <label for="fname">No Profil</label>
    <input type="text" id="fname" placeholder="Your name.." name="noprofil">

    <label for="lname">judul profil</label>
    <input type="text" id="lname" placeholder="Your last name.." name="judulprofil">


    <label for="subject">isi profil</label>
    <br>
    <textarea id="subject" placeholder="Write something.." style="height:200px" name="isiprofil"></textarea>
    <br>
    <input type="submit" name="submit" value="submit">
  </form>
</div>

</body>
</html>
