<!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' href='theme/css/style.css'/>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <style>
body {font-family: Arial, Helvetica, sans-serif;}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
<!-- Main Header -->
        <div class='main-header'>
            <h2>Wonderful Banjarnegara</h2>
        </div>
        <nav>
            <ul>
                <li><a href='../index.php'>home</a></li>
                <li><a href='../logout.php'>Logout</a></li>
            </ul>
        </nav>
    <!--Container-->

</head>
<body>
<br>
<br>
<center><h2>Data Profil</h2></center>

<div class="container">
  <?php
  include 'connect.php';
    $query =mysqli_query($koneksi, "SELECT * FROM profil");
    $cek =mysqli_num_rows($query);
    if($cek>0) {
      echo"
        <table class='table table-bordered'>
            <tr>
                <th>no</th>
                <th>judul</th>
                <th>aksi</th>
            </tr>
            ";
            $nomor=1;

            while($row=mysqli_fetch_array($query)) {
            $judul=$row['judulprofil'];
            $isi=$row['isiprofil'];
            $nomor=$row['noprofil'];
            ?>
                 <tr>
                    <td><?php echo $nomor ?></td>
                    <td><?php echo $judul ?></td>
                    <td>
                        <a href="profiledit.php?id=<?php echo $row['noprofil']; ?>" class="btn btn-primary">edit</a>
                        <a href="hapus.php?id=<?php echo $row['noprofil']; ?>" class="btn btn-danger">hapus</a>

                    </td>
                </tr>
            <?php

        }
    echo"</table>";
     }else{
     echo"belum ada profil";
 }
 ?>

</div>

</body>
</html>
