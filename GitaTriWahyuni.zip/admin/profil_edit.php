<?php
include 'header_admin.php';
include 'sidebar_admin.php';
include 'connect.php';
$id=$_GET["id"];
$query=mysqli_query($koneksi,"SELECT * FROM profil WHERE no_profil ='$id'");
$fec =mysqli_fetch_array($query);

?>
	<div class="content-wrapper">
		<section class="content-header">
			<h1>
			Edit Profil
			</h1>
		</section>

			<section class="content">
				<div class="row">
					<!-- left column -->
					<div class="col-md-6">
						<!-- general form elements -->
						<div class="box box-primary">
							<div class="box-header with-border">
								<h3 class="box-title"></h3>
							</div><!-- /.box-header -->

		<form role="form" action="profil_proses_edit.php" method="POST">
								<div class="box-body">
								<div class="form-group">
										<label for="exampleInputEmail1">No Profil</label>
										<input type="text" class="form-control" readonly="TRUE" value='<?php echo $fec["no_profil"];?>' name="no_profil" id="no_profil">
									</div>
									<div class="form-group">
										<label for="exampleInputEmail1">Judul Profil</label>
										<input type="text" class="form-control"name="judul_profil" id="judul_profil" placeholder="judul_profil" value='<?php echo $fec["judul_profil"];?>'>
									</div>
									<div class="form-group">
										<label for="exampleInputPassword1">Isi Profil</label>
										<textarea class="textarea" placeholder="isi_profil" style="width: 100%;height: 125px;font-size: 14px; line-height: 18px;border:1px solid #dddddd;padding: 10px;"name="isi_profil" id="isi_profil"><?php echo $fec["isi_profil"];?></textarea>
									</div>
									</div>
								</div><!-- /.box-body -->

								<div class="box-footer col-md-8">
									<button type="submit" class="btn btn=primary" name="submit">Submit</button>
								</div>
							</form>
			</div> 
		</div>
		</div>
	</section>


	<?php
	include 'footer_admin.php';
	?>



