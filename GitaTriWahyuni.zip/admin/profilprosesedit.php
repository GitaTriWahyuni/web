<?php
include 'connect.php';
$judul=$_POST['judulprofil'];
$isi=$_POST['isiprofil'];
$no=$_POST['noprofil'];
$query = mysqli_query($koneksi, "UPDATE profil SET noprofil ='$no', judulprofil = '$judul', isiprofil ='$isi' WHERE noprofil = '$no'");
if($query) {
	echo '<script>alert("berhasil"); window.location=("profildata.php");</script>';
}
else{
	echo "gagal";
}

?>