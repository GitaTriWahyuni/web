<!doctype>
<html>
	<head>
		<title>Artikel - Wonderful Banjarnegara</title>
		<link rel='stylesheet' href='theme/css/style.css'/>
	</head>
	
	<body>
	<!-- Main Header -->
		<div class='main-header'>
			<h2>Wonderful Banjarnegara</h2>
		</div>
		<nav>
			<ul>
				<li><a href='index.php'>Home</a></li>
				<li><a href='artikel.php'>Artikel</a></li>
				<li><a href='galeri.php'>galeri</a></li>
				<li><a href='login.php'>Login</a></li>
			</ul>
		</nav>
	<!--Container-->
		<div class='container'>
			<div class='main-wrapper'>
				<div class='left'>
					<h2>Selamat Datang di Wonderful Banjarnegara</h2><br/><hr><br/>
					<div class='main'>
						<h2>Banjarnegara</h2>
						<p class='small'>Di Poskan oleh <b>Gita Tri Wahyuni</b> - Pada 06-04-2018</p>
						<img src="6.jpg" >
						<h1>Banjarnegara</h1>
						<p class='justify'>Banjarnegara adalah sebuah kabupaten di Provinsi Jawa Tengah, Indonesia. Ibukotanya bernama Banjarnegara juga. Kabupaten Banjarnegara berbatasan dengan Kabupaten Pekalongan dan Kabupaten Batang di utara, Kabupaten Wonosobo di timur,Kabupaten Kebumen di Selatan, dan Kabupaten Purbalingga di Barat.</p>
					</div>
				</div>
				<div class='right'>
					<div class='title'>
						<h3>Pencarian Artikel</h3>
					</div>
					<div class='widget'>
						<form method='POST' action='artikel.html'>
							<input type='text' name='cari' placeholder='Cari Artikel disini...'/><br/><br/>
							<input type='submit' value='Cari !' class='button'/>
						</form>
					</div>
					<div class='title'>
						<h3>Login Area</h3>
					</div>
					<div class='widget'>
						<form method='POST' action='#'>
							<input type='text' name='username' placeholder='Username...'/><br/><br/>
							<input type='password' name='password' placeholder='*******'/><br/><br/>
							<input type='submit' value='Login !' class='button'>
						</form>
					</div>
				</div>
				
			</div>
			<div class='footer'>
				<p>Copyright &copy; 2018 - Beautiful Banjarnegara</p>
			</div>
		</div>
	<script src='theme/js/jquery.js'></script>
	<script>
	$(function(){
		$(".slider img:gt(0)").hide();
		setInterval(function(){
		$(".slider img:first-child")
		.fadeOut()
		.next(this)
		.fadeIn()
		.end()
		.appendTo(".slider");
		},3000);
	});
	</script>
	</body>
</html>