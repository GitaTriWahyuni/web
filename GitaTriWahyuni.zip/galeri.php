<!doctype>
<html>
	<head>
		<title>Artikel - Wonderful Banjarnegara</title>
		<link rel='stylesheet' href='theme/css/style.css'/>
	</head>
	
	<body>
	<!-- Main Header -->
		<div class='main-header'>
			<h2>Wonderful Banjarnegara</h2>
		</div>
		<nav>
			<ul>
				<li><a href='index.php'>Home</a></li>
				<li><a href='artikel.php'>Artikel</a></li>
				<li><a href='galeri.php'>galeri</a></li>
				<li><a href='login.php'>Login</a></li>
			</ul>
		</nav>
	<!--Container-->
		<div class='container'>
			<div class='main-wrapper'>
				<div class='left'>
					<h2>Selamat Datang di Wonderful Banjarnegara</h2><br/><hr><br/>
					<div class='main'>
						<h2>Galery Banjarnegara</h2>
						<p class='small'>Di Poskan oleh <b>Administrator</b> - Pada 28-02-2015</p>
						<h2>Banjarnegara</h2>
						<img src="2.jpg" width="250px" height="250px">
						<img src="3.jpg" width="250px" height="250px">
						<img src="4.jpg" width="250px" height="250px">
						<img src="5.jpg" width="250px" height="250px">
					</div>
				</div>
				<div class='right'>
					<div class='title'>
						<h3>Pencarian Artikel</h3>
					</div>
					<div class='widget'>
						<form method='POST' action='artikel.html'>
							<input type='text' name='cari' placeholder='Cari Artikel disini...'/><br/><br/>
							<input type='submit' value='Cari !' class='button'/>
						</form>
					</div>
					<div class='title'>
						<h3>Login Area</h3>
					</div>
					<div class='widget'>
						<form method='POST' action='#'>
							<input type='text' name='username' placeholder='Username...'/><br/><br/>
							<input type='password' name='password' placeholder='*******'/><br/><br/>
							<input type='submit' value='Login !' class='button'>
						</form>
					</div>
				</div>
				
			</div>
			<div class='footer'>
				<p>Copyright &copy; 2018 - Beautiful Banjarnegara</p>
			</div>
		</div>
	<script src='theme/js/jquery.js'></script>
	<script>
	$(function(){
		$(".slider img:gt(0)").hide();
		setInterval(function(){
		$(".slider img:first-child")
		.fadeOut()
		.next(this)
		.fadeIn()
		.end()
		.appendTo(".slider");
		},3000);
	});
	</script>
	</body>
</html>