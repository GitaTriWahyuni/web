<?php session_start();
ob_start ();
include 'connect.php';
$username=$_POST['username'];
$password=$_POST['password'];

$cek=mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$username'AND password='$password'");
$cek2=mysqli_num_rows($cek);
$ceklagi=mysqli_fetch_object($cek);
if($cek2 > 0) {
	$_SESSION['email'] = $ceklagi->email;
	$_SESSION['password'] = $ceklagi->password;
	header("location:admin/profildata.php");
}
else{
	echo "<script>alert('login gagal.SILAHKAN ULANGI.'); window.location=('login.php');</script>";
}
?>